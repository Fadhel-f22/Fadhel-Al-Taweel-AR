#include <stdio.h>
int main ()
{
	int num_city = 10;
	int populations[num_city];
    	int total = 0;
    	int max =0;
        int min =0;
	float average;

	for (int i=0; i < num_city; i++)
	{
		printf("enter the population of city %d\n",i+1);
		scanf(" %d",&populations[i]);
		total = total + populations[i];
		if (i==0) {
			max = min = populations[i];
		}	
		else if (populations[i] > max)
		{	
			max = populations[i];
		}
		if (populations[i] < min)
		{
			min = populations[i];
		}
	}
	for (int k = num_city-1; k>=0; --k)
	{	printf("the population in reverse order: %d\n",populations[k]);

	}

	average = total/num_city;

	printf("mean population:%.2f\n",average);
	printf("Max population: %d\n", max);
	printf("Min population: %d\n", min);

	return 0;
}
