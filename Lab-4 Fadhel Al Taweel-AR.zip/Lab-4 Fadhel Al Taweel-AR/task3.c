#include <stdio.h> 
#include <stdlib.h>
#include <time.h>

int main ()
{
	srand(time(NULL));

	int x = rand() % 10;
	int y = rand() % 10;
	int matrix [10][10];

	printf("\n");

	for (int i = 0; i<10;i++)
	{
		for (int j = 0; j < 10;j++)
		{
			if (x == i && y == j)
			{
				printf("Hurrah!, I have found the hidden treasure at (%d,%d)\n",x,y);
				return 0;
			}
		}
	}
	return 0;
}


