#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main ()
{
        srand(time(NULL));

	int r = rand() % 256;
	int g = rand() % 256;
	int b = rand() % 256;
	
	int image [10][10][3];
	int grayscaleImage [10][10];


	for (int i = 0; i<10 ; i++)
	{	
		for (int j = 0; j<10; j++)
		{
			image [i][j][0] = r;
			image [i][j][1] = g;
			image [i][j][2] = b;
		}
	}

	for (int i = 0; i<10 ; i++)
        {
                for (int j = 0; j<10; j++)
                {
                       grayscaleImage [i][j] = ((0.299*image[i][j][0])+(0.587*image[i][j][1])+(0.114*image[i][j][2]));

                }
        }

	for (int i = 0; i<10; i++)
	{
		for (int j=0;j<10;j++)
		{
			printf("(%3d, %3d, %3d)", image [i][j][0], image [i][j][1], image [i][j][2]);
		}
		printf("\n");
	}
	printf("\n");
	printf("\n");


	for (int i = 0; i<10; i++)
	{
		for (int j = 0; j<10; j++)
		{
			printf("%3d ", grayscaleImage [i][j]);
		}
		printf("\n");
	}
		return 0;
}
