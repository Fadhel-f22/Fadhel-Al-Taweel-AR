#include <stdio.h>
int main()
{
        int N;
	int i=1;
	int k =1;
	int j=1;	

        printf("please enter the numberof rows (N)\n");
        scanf("%d",&N);

	while (i<=N)
	{
		j=1;
		k=1;
		while(k<=N-i)
		{
			printf(" ");
			++k;
		}
		while(j<=i)
		{
			printf("*");
			j++;
		}
		
		printf("\n");
		++i;
	}

	return 0;
}

      

