#include <stdio.h>
int main ()
{
	int Minutes=0;
	int seconds=0;
	int k; 
	printf("please enter the number of minutes\n");
	scanf("%d",&Minutes);

	int count[Minutes];
	count[0]=0;

	for (int k =1;k<=Minutes; ++k )
	{ 
		count[k]=count[0]+1;
	}


	for (int i=0; i<Minutes ;i++)
	{
		for (int j =0 ; j<60;++j)
		{ 
			printf("%d : %d\n", count[i],j);
		}
		printf("\n");
	}

	return 0;
}

