#include <stdio.h>
#include <stdlib.h>
int main()
{
	int N;
        float a, b ;
	
	printf("this program to calculate (z=ax + by)\n");
	
	printf("please enter the size of your vectors:\n");
	scanf("%d", &N);
	
	int *x = (int*) malloc(N * sizeof(int));
	int *y = (int*) malloc(N * sizeof(int));
	int *z = (int*) malloc(N * sizeof(int));
	
	printf("please enter your scaler value for a:\n");
	scanf("%f",&a);
	printf("please enter your scaler value for b:\n");
	scanf("%f",&b);
	
	for (int i=0; i<N ; ++i){
		printf("Enter elements for x vector:\n");
		scanf("%d", &x[i]);
	}

	for (int i=0; i<N ; ++i){
                printf("Enter elements for y vector:\n");
                scanf("%d", &y[i]);
        }
	
	for (int i=0; i<N; ++i){
		x[i]=a*x[i];
		y[i]=b*y[i];
	}

	for (int i=0; i<N; ++i){
		z[i]= x[i]+y[i];
	}

	printf("your z vector is: \n");
	for (int i=0; i<N; ++i){
		printf(" %d", z[i]);
	}

	printf("\n");
		
	return 0;
}

