#include <stdio.h>
#include <stdlib.h>
int main()
{
	char input ;
	int integer =0;
	int *stack = (int*) malloc(0 * sizeof(int));
	int i=-1;
	int size=0;
	while(1){
		i+=1;
		printf("Enter a command (p: push, o:pop, d: display, e: exit) :\n");
		scanf(" %c", &input);
		
		if (input == 'p'){
			size+=1;
			stack= (int*) realloc(stack, size * sizeof(int));
			printf("Enter an integer to push:\n");
			scanf("%d", &stack[size-1]);
		}
		else if (input == 'o'){
			size-=1;
			stack= (int*) realloc(stack, size * sizeof(int));
		}	
		else if (input =='d'){
			printf("current stack: %d\n",stack[size-1]);
		}
		else if (input == 'e'){
			free(stack);
			return 0;
		}
		else{
			printf("invalid, Please enter 'p', 'o', 'd', or 'e'.\n");
			continue;	
		}
	}

        return 0;
}


