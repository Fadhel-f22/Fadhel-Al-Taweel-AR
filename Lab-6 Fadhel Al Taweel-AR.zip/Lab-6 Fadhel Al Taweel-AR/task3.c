#include <stdio.h>
#include <stdlib.h>

int average_(int *integers, int size);
int DC_shift(int *integers, int size);
int average =0;
int main()
{
	int *integers = (int*) malloc (1* sizeof(int));
	if (integers == NULL){
		printf("Memory allocation is failed!");
		return 1;
	}

	char more = 'y';
	int size = 0;

	for (int i =0; more =='y' || more == 'Y'; i++)
	{
		printf("Enter a sample integer value: \n");
		scanf("%d", &integers[i]);

		printf("Do you want to add more samples? \n");
		scanf(" %c", &more);	
		
		
		if(more == 'y')
		{
			integers = (int*) realloc(integers, (i+1) * sizeof(int));
		}		
		size += 1;
	}
	
	
	printf("You entered the following samples? (y/n):\n");
	for (int j=0 ; j<size ; j++){
		printf("%d,", integers[j]);
	}
	printf("\n");
		
	average = average_(integers,size);
	printf("Calculated average (DC value):%d\n", average);

	for (int i = 0; i<size; i++){
                integers[i] = integers[i] - average;
	}
	printf("Final adjusted samples after DC shift:\n");
	for (int j=0 ; j<size ; j++){
            	 printf("%d,", integers[j]);
        }
        printf("\n");

  	


        return 0;
}

int average_(int *integers, int size){
	int total = integers[0];
	for (int i = 1; i<size; i++){
		total = total + integers[i];
	}
	average = total / size;
	return average;
}
