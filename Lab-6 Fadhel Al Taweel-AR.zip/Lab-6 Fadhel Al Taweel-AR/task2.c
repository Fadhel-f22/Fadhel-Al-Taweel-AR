#include <stdio.h>
#include <stdlib.h>
int main()
{
	int size = 0;
	
	char *stri1 = (char*) malloc (20 * sizeof(char));
	char *stri2 = NULL;
	printf("please enter any inputs within 20 char: \n");
	fgets(stri1, 20, stdin);
//	puts(stri1);
	
	for (int i=0; i<20 ; ++i){
		size+=1 ;
		if (stri1[i] == 0){
			size -=1;
			break ;
		}
	}
	printf("%d\n",size);
	
	int x = size-1;
	int y = 0;

	//stri1 = (char*) realloc(stri1, 3*sizeof(char));
	//puts(stri1);
	
	for (int i = x ; i>=0 ; i--){
		
		stri2 = (char*) realloc (stri2, y * sizeof(char));
		stri2[y] = stri1[x];
//		puts(stri2);	

		stri1 = (char*) realloc(stri1, x * sizeof(char));
		y+=1;	
		x-=1;
		
	}

	stri2 = (char*) realloc (stri2, y * sizeof(char));
	stri2[y] = '\0';

	printf("Here your input in reverse order:\n");

	for (int i = 0 ; i < y ; i++){
	       printf("%c", stri2[i]);
      	}	       
	printf("\n");

        return 0;
}

