#include <stdio.h>

int add_integer(int,int);
float add_float(float,float);
float circle_area (float);
float rectangle_area (float,float);
int factorial (int);

int main()
{
	int a;
	int b;
	printf("Enter your int num1:\n");
        scanf("%d", &a);
	printf("Enter your int num2:\n");
        scanf(" %d", &b);

	int sum1= add_integer(a,b);
        printf("The addition for integers:%d\n", sum1);

	float c;
	float d;
	printf("Enter your int num1:\n");
        scanf("%f", &c);
        printf("Enter your int num2:\n");
        scanf(" %f", &d);

	float sum2 = add_float(c,d);
        printf("The addition for floats:%.2f\n",sum2);

	float r;
	printf("Enter your raadius:\n");
	scanf("%f", &r);

	float area1 = circle_area(r);
        printf("The circlar area:%.2f\n", area1);	

	float w;
	float l;
	printf("Enter your width:\n");
        scanf("%f", &w);
	printf("Enter your length:\n");
        scanf("%f", &l);

	float area2 = rectangle_area(w,l);
        printf("The rectangler area:%.2f\n", area2);

	int N;
	printf("Enter your number for factorial:\n");
        scanf(" %d", &N);

	int fact_N = factorial(N);
	printf("The factorial is:%d\n", fact_N);

	return 0;
}

int add_integer(int a,int b)
{
	return a+b;
}

float add_float(float c,float d)
{
        return c+d;
}

float circle_area (float r)
{
	return 3.14*r*r;
}

float rectangle_area (float w,float l)
{
	return w*l; 
}

int factorial (int N)
{
	if (N==0)
		return 1;
	else
	return N*factorial(N-1);
}
