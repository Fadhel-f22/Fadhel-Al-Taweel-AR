#include <stdio.h>

int main()
{
	int value = 0xA0007B;
	int *p;
	p = &value;
	
	char* new_pointer = (char *)p;
	int size = sizeof(p)*8;
	printf("the architecture of your system is: %d -bit\n",size);
	printf("the orginal addres: %p\n",p);

	printf("The value of Least Significant Byte is: %d\n",*new_pointer);

	return 0;
}	
