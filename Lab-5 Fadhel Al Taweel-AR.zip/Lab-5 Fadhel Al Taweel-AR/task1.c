#include <stdio.h>
#define size 4

int main()
{
	char array1 [size];
	int array2 [size];
	short array3 [size];
	double array4 [size];	
	
	printf("Integer Array:\n");	
	for (int i=0; i<size ; i++)
	{
		printf("%p\n", &array1[i]);
	}
	printf("Character Array:\n");
	for (int i=0; i<size ; i++)
        {
                printf("%p\n", &array2[i]);
        }
	printf("short Array:\n");
	for (int i=0; i<size ; i++)
        {
                printf("%p\n", &array3[i]);
        }
	printf("double Array:\n");
	for (int i=0; i<size ; i++)
        {
                printf("%p\n", &array4[i]);
        }


	return 0;
}
